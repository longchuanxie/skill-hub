---
name: test-skill
description: This is a test skill for validation
version: 1.0.0
category: testing
tags: test, validation, demo
author: Test Author
license: MIT
compatibility: claude-3.5, claude-4.0
---

# Test Skill

This is a test skill description.

## Instructions

1. First instruction
2. Second instruction
3. Third instruction

## Notes

Additional notes about the skill.
